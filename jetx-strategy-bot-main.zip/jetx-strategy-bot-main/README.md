# jetx-strategy-bot
Telegram bot for JetX game strategy
